//
//  HX_PhotosFooterView.h
//  测试
//
//  Created by 洪欣 on 16/8/24.
//  Copyright © 2016年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HX_PhotosFooterView : UICollectionReusableView
@property (assign, nonatomic) NSInteger total;
@end
