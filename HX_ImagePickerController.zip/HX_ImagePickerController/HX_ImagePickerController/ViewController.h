//
//  ViewController.h
//  HX_ImagePickerController
//
//  Created by 洪欣 on 16/8/25.
//  Copyright © 2016年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

