//
//  PhotoAndVideoViewController.h
//  HX_ImagePickerController
//
//  Created by 洪欣 on 16/8/31.
//  Copyright © 2016年 洪欣. All rights reserved.
//

#import "ViewController.h"

@interface PhotoAndVideoViewController : ViewController

@end
